#include "Play_UI.h"
#include "Schedule_UI.h"

#include "../Common/List.h"
#include "../Service/Play.h"

#include <stdio.h>
#include <stdlib.h>

void Play_UI_ShowList(play_list_t list, Pagination_t paging) {

}

void Play_UI_MgtEntry() {
}

int Play_UI_Add(void) {
	return 0;

}

int Play_UI_Modify(int id) {
	return 0;
}

int Play_UI_Delete(int id) {
	return 0;
}

int Play_UI_Query(int id) {
	return 0;
}
