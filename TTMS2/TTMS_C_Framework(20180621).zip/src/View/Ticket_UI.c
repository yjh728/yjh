#include "Ticket_UI.h"

#include "../Common/List.h"
#include "../Service/Ticket.h"
#include "../Service/Schedule.h"
#include "../Service/Play.h"
#include "../Service/Studio.h"

#include <stdio.h>
#include <stdlib.h>

int Ticket_UI_MgtEntry(int schedule_id) {
	return 0;
}

void Ticket_UI_Query(void) {
}

int Ticket_UI_ShowTicket(int ticket_id) {
}
