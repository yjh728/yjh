#include "SalesAnalysis_UI.h"

#include "../Common/list.h"
#include "../Service/Account.h"
#include "../Service/Ticket.h"
#include "../Service/Play.h"
#include "../Service/Schedule.h"
#include "../Service/Sale.h"

#include <stdio.h>
#include <stdlib.h>

//ͳ��Ʊ������
void SalesAnalysis_UI_MgtEntry (){

}
