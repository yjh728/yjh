/*
 * Studio_UI.h
 *
 *  Created on: 2015��4��25��
 *      Author: Administrator
 */

#ifndef STUDIO_UI_H_
#define STUDIO_UI_H_


int Studio_UI_Add(void);

int Studio_UI_Modify(int id);

int Studio_UI_Delete(int id);


void Studio_UI_MgtEntry(void);

#endif /* STUDIO_UI_H_ */
